import { Config } from './appConfig';
import { Injectable } from "@angular/core";
import {HttpHeaders} from "@angular/common/http";
import { Http, Headers } from "@angular/http";
import {HttpClient, JsonpClientBackend} from "@angular/common/http";
import "rxjs/add/operator/toPromise";


@Injectable()
export class FoodsService {
    private headers = new HttpHeaders({
        "user-key": Config.ZOMATO_API_KEY
    });
    constructor(private http: HttpClient) {
    }

    getJournalFood(): Promise<any> {
        return this.http.get(Config.ZOMATO_API_URL + "?res_id=" + Config.JOURNAL_ID, {headers: this.headers})
                        .toPromise()
                        .catch(this.handleError);
    }
    getAstraFood(): Promise<any> {
        return this.http.get(Config.ZOMATO_API_URL + "?res_id=" + Config.ASTRA_ID, {headers: this.headers})
                        .toPromise()
                        .catch(this.handleError);
    }

    getDelfinFood(): Promise<any> {
        return this.http.get(Config.ZOMATO_API_URL + "?res_id=" + Config.DELFIN_ID, {headers: this.headers})
                        .toPromise()
                        .catch(this.handleError);
    }

    getPrestoFood(): Promise<any> | void {
        function myFunction(item: any) {
            console.log("item: ", item);
        }
        const xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState === 4 && this.status === 200) {
                myFunction(this);
            }
        };
        xhttp.open("GET", Config.PRESTO_URL, true);

        xhttp.withCredentials = true;
        // xhttp.setRequestHeader("Access-Control-Allow-Origin", "http://www.restaurantpresto.sk")
        xhttp.send();
        /*
        return this.http.get("http://www.restaurantpresto.sk/sk/menu/presto-bbc-i/7.7.2017/")
                        .toPromise()
                        .then(response => console.log(response))
                        .catch(this.handleError);
                        */
    }
    private handleError(error: any): Promise<any> {
        return Promise.reject(error.message || error);
    }
}
